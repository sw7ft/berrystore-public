RISC-V Emulator for BlackBerry 10
================================

This package contains the mini-rv32ima RISC-V emulator for BlackBerry 10 devices,
along with multiple Linux kernel images to run.

Files included:
- bin/mini-rv32ima: The RISC-V emulator executable
- images/: Directory containing various RISC-V Linux kernel images
- scripts/: Helper scripts to run different images
- run_all.sh: Master script to select which image to run

Available images:
- Linux 5.18.0 ProfileTest: A minimal test image for kernel 5.18.0
- Linux 6.5.12 ProfileTest: A minimal test image for kernel 6.5.12
- Linux 6.8-rc1 ProfileTest: A minimal test image for kernel 6.8-rc1
- Linux with Doom: Image with Doom game (requires more memory)

To run the emulator:
1. Make the executables permissions: chmod +x bin/mini-rv32ima scripts/*.sh run_all.sh
2. Run the master script: ./run_all.sh
3. Select which image to run

For kernel prints, add -k to the command:
    ./run_all.sh -k

