#!/bin/sh
# Run the mini-rv32ima emulator with the 5.18.0 ProfileTest image
./bin/mini-rv32ima -f images/profile-5.18.0/Image.ProfileTest -k "console=hvc0 earlycon=sbi"
