#!/bin/sh
# Run the mini-rv32ima emulator with the 6.8-rc1 ProfileTest image
./bin/mini-rv32ima -f images/profile-6.8-rc1/Image -k "console=hvc0 earlycon=sbi"
