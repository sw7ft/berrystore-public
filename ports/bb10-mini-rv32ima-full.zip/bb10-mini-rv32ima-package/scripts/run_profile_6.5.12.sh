#!/bin/sh
# Run the mini-rv32ima emulator with the 6.5.12 ProfileTest image
./bin/mini-rv32ima -f images/profile-6.5.12/Image -k "console=hvc0 earlycon=sbi"
