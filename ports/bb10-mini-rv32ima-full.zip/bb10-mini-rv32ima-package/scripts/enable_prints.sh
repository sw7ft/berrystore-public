#!/bin/sh
# Add this to any command to enable kernel prints
echo "To enable kernel prints, add -k to the end of any command."
echo "Example: ./scripts/run_profile_5.18.0.sh -k"
