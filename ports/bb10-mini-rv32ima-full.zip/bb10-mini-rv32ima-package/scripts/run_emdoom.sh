#!/bin/sh
# Run the mini-rv32ima emulator with the emdoom image
./bin/mini-rv32ima -f images/emdoom/Image-emdoom-MAX_ORDER_14 -k "console=hvc0 earlycon=sbi"
