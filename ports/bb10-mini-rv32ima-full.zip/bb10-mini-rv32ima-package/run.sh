#!/bin/sh
# Run the mini-rv32ima emulator with Linux
./bin/mini-rv32ima images/Image.ProfileTest
