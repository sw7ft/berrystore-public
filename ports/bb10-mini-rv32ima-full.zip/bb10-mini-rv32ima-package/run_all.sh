#!/bin/sh
echo "RISC-V Linux Emulator for BlackBerry 10"
echo "========================================"
echo
echo "Choose an image to run:"
echo "1. Linux 5.18.0 ProfileTest"
echo "2. Linux 6.5.12 ProfileTest"
echo "3. Linux 6.8-rc1 ProfileTest"
echo "4. Linux with Doom"
echo "q. Quit"
echo
echo -n "Enter your choice: "
read choice

case "$choice" in
  1) 
    echo "Running Linux 5.18.0 ProfileTest..."
    ./bin/mini-rv32ima -f images/profile-5.18.0/Image.ProfileTest -k "console=hvc0 earlycon=sbi" "$@"
    ;;
  2) 
    echo "Running Linux 6.5.12 ProfileTest..."
    ./bin/mini-rv32ima -f images/profile-6.5.12/Image -k "console=hvc0 earlycon=sbi" "$@"
    ;;
  3) 
    echo "Running Linux 6.8-rc1 ProfileTest..."
    ./bin/mini-rv32ima -f images/profile-6.8-rc1/Image -k "console=hvc0 earlycon=sbi" "$@"
    ;;
  4) 
    echo "Running Linux with Doom..."
    ./bin/mini-rv32ima -f images/emdoom/Image-emdoom-MAX_ORDER_14 -k "console=hvc0 earlycon=sbi" "$@"
    ;;
  q) exit 0 ;;
  *) echo "Invalid choice" ;;
esac
