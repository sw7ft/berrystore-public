* Type the command with no parameters for help.

Usage:

a.) Verify the compliance of one or more APKs against a target version of the
BlackBerry Android app runtime defined in the <blacklist-file>, by default in
blackberry/. Besides the standard output, *wrn files are produced for each
non-compliant apk along with a final _Apk2BarVerifier_<time-stamp>.sum

>bin\apk2barVerifier <apk-dir>|<apk-file> [<blacklist-file>] [<Android SDK path*>]
 * <Android SDK path> needs to be provided or set %ANDROID_HOME%

b.) Verify 1st if necessary and produce BAR files from APKs

>bin\apk2bar <apk file/folder> [<blacklist-file>] [<Android SDK path>] [-t <bar-dir>] [-w[1-5]] [-a <author-name>] [-d <debug-token-bar>] [-m] [-rv] [-etl | -etn]

c.) Sign a set of BARs with developer and RIM keys

>bin\batchbar-signer <bar-dir>|<bar-file> <dev-cert-path> <dev-cert-pass> [<csk-pass>] [-t <signed-bar-target-dir>]

d.) Deploy a BAR app for testing on PlayBook device or VMWare simulator

>bin\blackberry-deploy -installApp -device <deviceIP> -package <BAR file path> -password <device-password>

e.) Deploy a set of BAR(s) for testing on PlayBook device or VMWare simulator

>bin\batchbar-deploy <bar-dir> <deviceIP> <device-password>
