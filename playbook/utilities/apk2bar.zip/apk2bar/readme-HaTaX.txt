Hello fellow BlackBerry lovers!!!

I've made a few batch files before to make things easier, and here
is the latest installment to simplify the two step process to porting
Android APKs over to the Android Player on the BlackBerry Playbook.

apk2bar-HaTaX.bat -

	This batch file processes the APK and converts it to a loadable BAR file.
	It will place the BAR file in the same directory the APK file was in.

	First things first, go get your Android SDK downloaded from here:

		http://developer.android.com/sdk/index.html

		When running the installer, remember where you installed the SDK!
		You're going to need that path in a future step, I installed to
		"C:\android-sdk" to keep things simple and clean.


	Second, get that SDK installed and download the "SDK Platform" from the
		"Android 2.3.3 (API10)" list in the Android SDK Manager tree.

	Third,  setup the apk2bar-HaTaX.bat file by opening it up in notepad and make
		sure the "ANDROIDSDK=" line has the correct path to the installed SDK.

	You're set at this point!  Just drag an APK onto the batch file in windows
		explorer and it should start working it's magic.  If the file isn't
		compatible you'll see that listed in the output at the end.


signbar-HaTaX.bat -

	This batch file signs the BAR file created by apk2bar-HaTaX.bat.

	First,  make sure you've gone through the steps to get your signing keys from RIM.
		Start that process at this URL:

		https://www.blackberry.com/SignedKeys/	

	Second, get those keys activated and create a working p12 certificate file.
		Follow the steps at this URL if you need help:

		http://docs.blackberry.com/en/developers/deliverables/27280/Configure_app_signing_from_cmd_line_1463563_11.jsp

	Third,  setup the signbar-HaTaX.bat file by opening it up in notepad and make
		sure the 3 lines are properly filled out.  You should know where your
		.p12 file is, and the passwords for both the .p12 and the CSK password.
		(You created these passwords when you went through step 2 above)

	You're set again!  Just drag a BAR file made with apk2bar-HaTaX.bat onto the
		batch file in windows explorer and you will get a signed BAR file
		ready to be loaded on any Playbook running OS 2.0 with developer mode on.



Good luck!
