import http.server
import socketserver
import json
import urllib.parse
import os
import asyncio

import requests  # <-- Using requests now

from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError
from telethon.sessions import SQLiteSession

# --------------------------------------------
#     FETCH TELEGRAM KEYS FROM REMOTE
# --------------------------------------------
API_ID = None
API_HASH = None

# URL to your text file containing lines like:
#   API_ID = 26728096
#   API_HASH = 'c6b92f27cd5e5882aeb9aa367e09d049'
REMOTE_KEYS_URL = "https://berrystore.sw7ft.com/keys/telegram.txt"

try:
    resp = requests.get(REMOTE_KEYS_URL)
    resp.raise_for_status()  # Raises an exception for 4xx/5xx errors
    content = resp.text
    
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("API_ID"):
            # Example line:  API_ID = 26728096
            parts = line.split("=", 1)
            API_ID = int(parts[1].strip())
        elif line.startswith("API_HASH"):
            # Example line:  API_HASH = 'c6b92f27cd5e5882aeb9aa367e09d049'
            parts = line.split("=", 1)
            raw = parts[1].strip()      # "'c6b92f27cd5e5882aeb9aa367e09d049'"
            raw = raw.strip("'\"")      # remove surrounding quotes
            API_HASH = raw
except Exception as e:
    print("Failed to retrieve or parse Telegram keys from remote text file:")
    print(e)
    import sys
    sys.exit(1)

# --------------------------------------------
#     TELETHON + PATH CONFIG
# --------------------------------------------

# Use an absolute base directory reference so we can safely load files
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Store the session file in the same directory as this script
SESSION_FILE_PATH = os.path.join(BASE_DIR, "session_name.session")

# Initialize Telethon client with a file-based session
client = TelegramClient(
    session=SQLiteSession(SESSION_FILE_PATH),
    api_id=API_ID,
    api_hash=API_HASH
)

# Globals for phone login
phone_number = None
phone_code_hash = None

PORT = 8010

class MyHttpRequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        """Handle all GET requests (serving HTML, checking session, listing rooms, etc.)."""
        parsed_path = urllib.parse.urlparse(self.path)

        # Before routing, ensure we can write to the session file (or remove an unusable one).
        self._ensure_session_writable()

        # We use asyncio to check "is_user_authorized()" properly
        loop = asyncio.get_event_loop()
        is_authorized = loop.run_until_complete(self._is_user_authorized())

        # If not authorized and not hitting the auth flow endpoints, redirect to /start_auth
        auth_endpoints = ['/start_auth', '/enter_code', '/auth.html', '/auth_code.html', '/favicon.ico']
        if not is_authorized and parsed_path.path not in auth_endpoints:
            self.send_response(302)
            self.send_header('Location', '/start_auth')
            self.end_headers()
            return

        # Normal routing
        if parsed_path.path == '/':
            # Serve main index (the chat UI)
            self.serve_file('index.html', 'text/html')

        elif parsed_path.path == '/start_auth':
            # Serve the phone number input page
            self.serve_file('auth.html', 'text/html')

        elif parsed_path.path == '/enter_code':
            # Serve the code input page
            self.serve_file('auth_code.html', 'text/html')

        elif parsed_path.path == '/get_rooms':
            # Return the list of rooms/chats as JSON
            loop = asyncio.get_event_loop()
            response = loop.run_until_complete(self.get_rooms())
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))

        elif parsed_path.path == '/get_messages':
            query = urllib.parse.parse_qs(parsed_path.query)
            chat_id = query.get('chat_id', [None])[0]
            if chat_id:
                loop = asyncio.get_event_loop()
                response = loop.run_until_complete(self.get_messages(int(chat_id)))
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response).encode('utf-8'))
            else:
                self.send_error(400, "chat_id is required")

        else:
            # Attempt to serve a static file or 404
            filepath = parsed_path.path.lstrip('/')
            full_path = os.path.join(BASE_DIR, filepath)
            if os.path.isfile(full_path):
                self.serve_file(filepath, 'text/html')
            else:
                self.send_error(404, "Page not found")

    def do_POST(self):
        """Handle all POST requests (/send_code, /validate_code, /send_message, etc.)."""
        parsed_path = urllib.parse.urlparse(self.path)

        if parsed_path.path == '/send_code':
            # Step 1: Request code from Telegram
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data)

            global phone_number, phone_code_hash
            phone_number = data.get('phone_number')
            if not phone_number:
                self.send_error(400, "phone_number is required")
                return

            loop = asyncio.get_event_loop()
            result = loop.run_until_complete(self.send_code_request(phone_number))
            if result.get('status') == 'ok':
                # Move on to enter_code page
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'next': '/enter_code'}).encode('utf-8'))
            else:
                # Error from Telethon or invalid phone number
                self.send_error(400, result.get('error', 'Unknown error'))

        elif parsed_path.path == '/validate_code':
            # Step 2: Validate code, sign in
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data)

            code = data.get('code')
            if not code:
                self.send_error(400, "code is required")
                return

            loop = asyncio.get_event_loop()
            result = loop.run_until_complete(self.validate_code(code))
            if result.get('status') == 'authorized':
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'next': '/'}).encode('utf-8'))
            else:
                self.send_error(400, result.get('error', 'Authorization failed'))

        elif parsed_path.path == '/send_message':
            # Send a message to a specific chat
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data)

            chat_id = data.get('chat_id')
            message = data.get('message')
            if not chat_id or not message:
                self.send_error(400, "chat_id and message are required")
                return

            loop = asyncio.get_event_loop()
            response = loop.run_until_complete(self.send_message(int(chat_id), message))
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))

        else:
            self.send_error(404, "Unsupported POST endpoint")

    def serve_file(self, file_path, content_type):
        """Serve a file (HTML, JS, etc.) from the BASE_DIR with the specified content type."""
        full_path = os.path.join(BASE_DIR, file_path)
        try:
            with open(full_path, 'rb') as f:
                self.send_response(200)
                self.send_header('Content-type', content_type)
                self.end_headers()
                self.wfile.write(f.read())
        except IOError:
            self.send_error(404, f"File not found: {file_path}")

    # ----------------------------------------------------------------------
    #    ASYNC HELPER METHODS
    # ----------------------------------------------------------------------
    async def _is_user_authorized(self):
        """Check if Telegram client has a valid, logged-in session."""
        if not client.is_connected():
            await client.connect()
        return await client.is_user_authorized()

    async def send_code_request(self, phone_number):
        """Ask Telegram to send a code to this phone number."""
        global phone_code_hash
        try:
            if not client.is_connected():
                await client.connect()
            # If already authorized, sign out first to re-initiate a new flow
            if await client.is_user_authorized():
                await client.log_out()

            result = await client.send_code_request(phone_number)
            phone_code_hash = result.phone_code_hash
            return {'status': 'ok'}
        except Exception as e:
            return {'status': 'error', 'error': str(e)}

    async def validate_code(self, code):
        """Validate the received code and sign into Telegram."""
        global phone_number, phone_code_hash
        try:
            if not client.is_connected():
                await client.connect()

            await client.sign_in(phone_number, code, phone_code_hash=phone_code_hash)
            return {'status': 'authorized'}
        except SessionPasswordNeededError:
            # If the account has 2FA enabled, you'd need to handle `client.sign_in(password=...)`
            return {'status': 'error', 'error': '2FA password needed (not implemented)'}
        except Exception as e:
            return {'status': 'error', 'error': str(e)}

    async def get_rooms(self):
        """Get a list of the user's chats."""
        if not client.is_connected():
            await client.connect()
        dialogs = []
        async for dialog in client.iter_dialogs():
            dialogs.append({'name': dialog.name, 'id': dialog.id})
        return dialogs

    async def get_messages(self, chat_id):
        """Fetch recent messages from a chat."""
        if not client.is_connected():
            await client.connect()

        messages = await client.get_messages(chat_id, limit=10)
        output = []
        for msg in messages:
            sender_entity = None
            if msg.sender_id:
                sender_entity = await client.get_entity(msg.sender_id)
            sender_name = (
                getattr(sender_entity, 'username', None) or
                getattr(sender_entity, 'first_name', 'Unknown')
            )
            output.append({
                'sender_name': sender_name,
                'message': msg.message,
                'date': str(msg.date)
            })
        return output

    async def send_message(self, chat_id, message):
        """Send a text message to the given chat ID."""
        if not client.is_connected():
            await client.connect()
        await client.send_message(chat_id, message)
        return {'status': 'Message sent'}

    # ----------------------------------------------------------------------
    #    SESSION FILE / PERMISSIONS HELPER
    # ----------------------------------------------------------------------
    def _ensure_session_writable(self):
        """
        If `session_name.session` already exists but is read-only or corrupted,
        remove or rename it so Telethon can recreate properly.
        """
        session_file = SESSION_FILE_PATH
        if os.path.exists(session_file):
            # Check if we can write to the file
            if not os.access(session_file, os.W_OK):
                # Attempt to fix permissions or remove it
                try:
                    os.chmod(session_file, 0o600)  # rw-------
                except Exception:
                    # If we cannot chmod, rename or remove the file
                    try:
                        os.remove(session_file)
                    except Exception:
                        # If removing also fails, rename
                        base, ext = os.path.splitext(session_file)
                        os.rename(session_file, base + '_old' + ext)


# ----------------------------------------------------------------------
#    RUN THE SERVER
# ----------------------------------------------------------------------
if __name__ == "__main__":
    Handler = MyHttpRequestHandler
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"Serving on port {PORT}")
        httpd.serve_forever()
