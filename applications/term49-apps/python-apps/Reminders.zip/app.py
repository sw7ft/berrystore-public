import os
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs
import traceback
from datetime import datetime, timedelta
import json
import subprocess
import threading
import tempfile
import time

# === Database Setup ===
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "notes.db")

# Connect to SQLite3 database (it will be created if it doesn't exist)
# Using check_same_thread=False to allow access from different threads
conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cursor = conn.cursor()

# Create the notes table if it doesn't exist
cursor.execute("""
    CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        subtitle TEXT NOT NULL,
        scheduled_time TEXT,  -- ISO format datetime string, nullable
        created_at TEXT NOT NULL,
        executed INTEGER DEFAULT 0  -- 0: Not executed, 1: Executed
    )
""")
conn.commit()
# === End Database Setup ===

# === Template Path Setup ===
script_dir = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_PATH = os.path.join(script_dir, "template.html")

try:
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        HTML_TEMPLATE = f.read()
except Exception as e:
    print(f"Error reading template file at {TEMPLATE_PATH}: {e}")
    HTML_TEMPLATE = "<html><body><h1>Error loading template</h1></body></html>"
# === End Template Path Setup ===

def execute_shell_command(title, subtitle, itemid="NoteApp"):
    """
    Executes the shell command to send a notification.

    Args:
        title (str): The title of the note.
        subtitle (str): The subtitle/content of the note.
        itemid (str): Identifier for the notification item.
    """
    payload = {
        "itemid": itemid,
        "title": title,
        "subtitle": subtitle,
        "target": "YourTarget",
        "targetAction": "YourTargetAction",
        "payload": "YourPayload",
        "payloadType": "YourPayloadType",
        "payloadURI": "YourPayloadURI"
    }
    json_payload = json.dumps(payload)

    try:
        with tempfile.NamedTemporaryFile(delete=False, mode="w", encoding="utf-8") as temp_file:
            temp_file.write(f"msg::notify\ndat:json:{json_payload}")
            temp_file_path = temp_file.name

        command = f"cat {temp_file_path} >> /pps/services/notify/control"
        subprocess.run(command, shell=True, check=True)
        print(f"Notification executed for note: {title}")
    except subprocess.CalledProcessError as e:
        print(f"Error executing notification for note '{title}': {e}")

def scheduler_thread():
    """
    Background thread that periodically checks for due notes and executes notifications.
    """
    while True:
        try:
            current_time = datetime.now()
            cursor.execute("""
                SELECT id, title, subtitle FROM notes
                WHERE (scheduled_time IS NOT NULL) AND (executed = 0) AND (datetime(scheduled_time) <= datetime(?))
            """, (current_time.isoformat(),))
            due_notes = cursor.fetchall()
            for note in due_notes:
                note_id, title, subtitle = note
                itemid = f"Note-{note_id}"
                execute_shell_command(title, subtitle, itemid)
                cursor.execute("UPDATE notes SET executed = 1 WHERE id = ?", (note_id,))
                conn.commit()
            time.sleep(60)
        except Exception as e:
            print(f"Error in scheduler thread: {e}")
            traceback.print_exc()
            time.sleep(60)

threading.Thread(target=scheduler_thread, daemon=True).start()

def generate_notes_html():
    """
    Retrieves all notes from the database and formats them into HTML.
    """
    cursor.execute("SELECT id, title, subtitle, scheduled_time, created_at, executed FROM notes ORDER BY id DESC")
    notes = cursor.fetchall()

    if not notes:
        return "<p>No notes available. Create one!</p>"

    html_parts = ['<ul>']
    for note in notes:
        id, title, subtitle, scheduled_time, created_at, executed = note
        if scheduled_time:
            if executed:
                display_time = f"Executed at: {scheduled_time}"
            else:
                display_time = f"Scheduled for: {scheduled_time}"
        else:
            display_time = "Executed Immediately"
        display_created_at = f"Created at: {created_at}"
        remove_button = f'''
            <form method="POST" action="/remove_note" style="display:inline;">
                <input type="hidden" name="note_id" value="{id}" />
                <input type="submit" value="Remove" />
            </form>
        '''
        message_html = f'''
            <li>
                <div>
                    <strong>Title:</strong> {title}<br>
                    <strong>Subtitle:</strong> {subtitle}<br>
                    <span class="timestamp">{display_time}</span><br>
                    <span class="timestamp">{display_created_at}</span>
                </div>
                {remove_button}
            </li>
        '''
        html_parts.append(message_html)
    html_parts.append('</ul>')
    return "\n".join(html_parts)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            if self.path == "/watchlist":
                content = '''
                    <h2>My Watch List</h2>
                    <p>Watch list feature is not implemented in this app.</p>
                    <p><a href="/">Back to Create Reminders</a></p>
                '''
            else:
                content = f'''
                    <h2>Create a Reminder</h2>
                    <form class="form-section" method="POST" action="/create_note">
                        <input type="text" name="title" placeholder=" Title" required /><br>
                        <input type="text" name="subtitle" placeholder="Subtitle" required /><br>
                        <label for="scheduled_time">Schedule Notification (optional):</label><br>
                        <input type="datetime-local" name="scheduled_time" /><br>
                        <input type="submit" value="Create Reminder" />
                    </form>
                    <h2>Your Reminders</h2>
                    {generate_notes_html()}
                '''
            page = HTML_TEMPLATE.replace('{{ content }}', content)
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(page.encode("utf-8"))
        except Exception as e:
            self.send_error(500, f"Internal Server Error: {e}")
            traceback.print_exc()

    def do_POST(self):
        try:
            if self.path == "/create_note":
                length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(length).decode('utf-8')
                params = parse_qs(body)

                title = params.get("title", [""])[0].strip()
                subtitle = params.get("subtitle", [""])[0].strip()
                scheduled_time_str = params.get("scheduled_time", [""])[0].strip()

                if not title or not subtitle:
                    response = "Title and Subtitle are required."
                else:
                    scheduled_time = None
                    if scheduled_time_str:
                        try:
                            scheduled_time = datetime.fromisoformat(scheduled_time_str)
                            if scheduled_time <= datetime.now():
                                response = "Scheduled time must be in the future."
                                scheduled_time = None
                        except ValueError:
                            response = "Invalid datetime format."
                            scheduled_time = None
                    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cursor.execute("""
                        INSERT INTO notes (title, subtitle, scheduled_time, created_at)
                        VALUES (?, ?, ?, ?)
                    """, (title, subtitle, scheduled_time.isoformat() if scheduled_time else None, created_at))
                    conn.commit()
                    note_id = cursor.lastrowid
                    if scheduled_time:
                        response = f"Note '{title}' scheduled for {scheduled_time}."
                    else:
                        itemid = f"Note-{note_id}"
                        execute_shell_command(title, subtitle, itemid)
                        response = f"Note '{title}' created and notification sent immediately."
                content = f'''
                    <h2>Create a Reminder</h2>
                    <p>{response}</p>
                    <form class="form-section" method="POST" action="/create_note">
                        <input type="text" name="title" placeholder="Note Title" required /><br>
                        <input type="text" name="subtitle" placeholder="Note Subtitle" required /><br>
                        <label for="scheduled_time">Schedule Notification (optional):</label><br>
                        <input type="datetime-local" name="scheduled_time" /><br>
                        <input type="submit" value="Create Note" />
                    </form>
                    <h2>Your Reminders</h2>
                    {generate_notes_html()}
                '''
                page = HTML_TEMPLATE.replace('{{ content }}', content)
                self.send_response(200)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(page.encode("utf-8"))

            elif self.path == "/remove_note":
                length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(length).decode('utf-8')
                params = parse_qs(body)

                note_id = params.get("note_id", [""])[0].strip()
                if note_id and note_id.isdigit():
                    cursor.execute("DELETE FROM notes WHERE id = ?", (note_id,))
                    conn.commit()
                response = "Note removed successfully." if cursor.rowcount > 0 else "Note not found."
                content = f'''
                    <h2>Remove Reminder</h2>
                    <p>{response}</p>
                    <p><a href="/">Back to Create Reminder</a></p>
                '''
                page = HTML_TEMPLATE.replace('{{ content }}', content)
                self.send_response(200)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(page.encode("utf-8"))
        except Exception as e:
            self.send_error(500, f"Internal Server Error: {e}")
            traceback.print_exc()

    def log_message(self, format, *args):
        return

if __name__ == "__main__":
    try:
        server_address = ('0.0.0.0', 8005)
        server = HTTPServer(server_address, Handler)
        print(f"Note-Taking App Server started at http://{server_address[0]}:{server_address[1]}")
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer shutting down.")
    except Exception as e:
        print(f"Error starting server: {e}")
        traceback.print_exc()
    finally:
        conn.close()
