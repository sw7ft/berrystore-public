import os
import sqlite3  # Import SQLite3 for database operations
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs
import traceback
from datetime import datetime  # To add timestamps
import re  # Import regular expressions module
from bs4 import BeautifulSoup
import requests

# === Database Setup ===
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stock_queries.db")

# Connect to SQLite3 database (it will be created if it doesn't exist)
# Using check_same_thread=False to allow access from different threads
conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cursor = conn.cursor()

# Create the stock_queries table if it doesn't exist
cursor.execute("""
	CREATE TABLE IF NOT EXISTS stock_queries (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		ticker TEXT NOT NULL,
		price REAL NOT NULL,
		timestamp TEXT NOT NULL
	)
""")
# Create the watchlist table if it doesn't exist
cursor.execute("""
	CREATE TABLE IF NOT EXISTS watchlist (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		ticker TEXT NOT NULL UNIQUE,
		timestamp TEXT NOT NULL
	)
""")
conn.commit()
# === End Database Setup ===

# === Template Path Setup ===
# Get the directory where the current script resides
script_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the absolute path to template.html
TEMPLATE_PATH = os.path.join(script_dir, "template.html")

# Read the HTML template from the absolute path
try:
	with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
		HTML_TEMPLATE = f.read()
except Exception as e:
	print(f"Error reading template file at {TEMPLATE_PATH}: {e}")
	HTML_TEMPLATE = "<html><body><h1>Error loading template</h1></body></html>"
# === End Template Path Setup ===

def fetch_stock_price(ticker):
	"""
	Scrapes the current stock price for the given ticker from Yahoo Finance.

	Args:
		ticker (str): The stock ticker symbol (e.g., 'AAPL').

	Returns:
		float: Current stock price if successful.
		None: If the ticker is invalid or data cannot be retrieved.
	"""
	url = f"https://finance.yahoo.com/quote/{ticker}"
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
					  ' Chrome/58.0.3029.110 Safari/537.3'
	}

	try:
		response = requests.get(url, headers=headers, timeout=5)
		response.raise_for_status()  # Raises HTTPError for bad requests (4XX or 5XX)
		soup = BeautifulSoup(response.text, 'html.parser')

		# Find the element that contains the stock price
		# As of the latest Yahoo Finance layout, the price is within a <fin-streamer> tag with data-field="regularMarketPrice"
		price_tag = soup.find('fin-streamer', {'data-field': 'regularMarketPrice'})
		
		if price_tag:
			price_text = price_tag.text.replace(',', '')  # Remove commas for thousands
			price = float(price_text)
			return price
		else:
			print(f"Price tag not found for ticker '{ticker}'.")
			return None

	except requests.exceptions.HTTPError as http_err:
		print(f"HTTP error occurred while fetching '{ticker}': {http_err}")
	except requests.exceptions.ConnectionError as conn_err:
		print(f"Connection error occurred while fetching '{ticker}': {conn_err}")
	except requests.exceptions.Timeout as timeout_err:
		print(f"Timeout error occurred while fetching '{ticker}': {timeout_err}")
	except requests.exceptions.RequestException as req_err:
		print(f"An error occurred while fetching '{ticker}': {req_err}")
	except ValueError as val_err:
		print(f"Value error: {val_err}")
	except Exception as e:
		print(f"An unexpected error occurred while fetching '{ticker}': {e}")

	return None

def generate_search_page_html():
	"""
	Generates the HTML content for the search page with the search form.
	"""
	search_form_html = '''
		<h2>Search for a Stock</h2>
		<form class="search-form" method="POST" action="/search">
			<input type="text" name="ticker" placeholder="Enter Stock Ticker (e.g., AAPL)" required />
			<input type="submit" value="Search Stocks" />
		</form>
	'''
	return search_form_html

def generate_search_results_html(search_results):
	"""
	Formats search results into HTML with 'Add to Watch List' buttons.

	Args:
		search_results (list of tuples): Each tuple contains (ticker, price, timestamp).

	Returns:
		str: HTML string of search results.
	"""
	if not search_results:
		return "<p>No search results to display.</p>"

	html_parts = ['<ul>']
	for result in search_results:
		ticker, price, timestamp = result
		# Check if the ticker is already in the watchlist
		cursor.execute("SELECT 1 FROM watchlist WHERE ticker = ?", (ticker,))
		in_watchlist = cursor.fetchone() is not None
		if in_watchlist:
			add_button = '<button disabled>In Watch List</button>'
		else:
			add_button = f'''
				<form method="POST" action="/add_watch" style="display:inline;">
					<input type="hidden" name="ticker" value="{ticker}" />
					<input type="submit" value="Add to Watch List" />
				</form>
			'''
		message_html = f'''
			<li>
				<strong>{ticker}</strong>: ${price:.2f} 
				{add_button}
			</li>
		'''
		html_parts.append(message_html)
	html_parts.append('</ul>')
	return "\n".join(html_parts)

def generate_watchlist_html():
	"""
	Fetches all watched stocks, refreshes their prices, and formats them into HTML.

	Returns:
		str: HTML string of the watchlist.
	"""
	cursor.execute("SELECT id, ticker, timestamp FROM watchlist ORDER BY id DESC")
	watchlist = cursor.fetchall()

	if not watchlist:
		return "<p>Your watch list is empty.</p>"

	html_parts = ['<ul>']
	for entry in watchlist:
		id, ticker, timestamp = entry
		price = fetch_stock_price(ticker)
		if price is not None:
			price_display = f"${price:.2f}"
		else:
			price_display = "N/A"
		# Optionally, add a button to remove from watchlist
		remove_button = f'''
			<form method="POST" action="/remove_watch" style="display:inline;">
				<input type="hidden" name="ticker" value="{ticker}" />
				<input type="submit" value="Remove" />
			</form>
		'''
		message_html = f'''
			<li>
				<strong>{ticker}</strong>: {price_display} 
				{remove_button}
			</li>
		'''
		html_parts.append(message_html)
	html_parts.append('</ul>')
	return "\n".join(html_parts)

class Handler(BaseHTTPRequestHandler):
	def do_GET(self):
		try:
			if self.path == "/watchlist":
				# Generate watchlist view
				watchlist_html = generate_watchlist_html()
				content = f'''
					<h2>My Watch List</h2>
					{watchlist_html}
					<p><a href="/">Back to Search</a></p>
				'''
			else:
				# Default to search page
				content = generate_search_page_html()
			# Replace the placeholder with actual content
			page = HTML_TEMPLATE.replace('{{ content }}', content)
			self.send_response(200)
			self.send_header("Content-type", "text/html; charset=utf-8")
			self.end_headers()
			self.wfile.write(page.encode("utf-8"))
		except Exception as e:
			self.send_error(500, f"Internal Server Error: {e}")
			traceback.print_exc()

	def do_POST(self):
		try:
			# Determine the path to handle different POST actions
			if self.path == "/search":
				# Handle search form submission
				length = int(self.headers.get('Content-Length', 0))
				body = self.rfile.read(length).decode('utf-8')
				params = parse_qs(body)
				
				ticker_input = params.get("ticker", [""])[0].strip().upper()

				# Validate ticker: 1-5 uppercase letters
				if re.fullmatch(r'[A-Z]{1,5}', ticker_input):
					price = fetch_stock_price(ticker_input)
					if price is not None:
						# Save the search query to the database
						timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
						cursor.execute("""
							INSERT INTO stock_queries (ticker, price, timestamp)
							VALUES (?, ?, ?)
						""", (ticker_input, price, timestamp))
						conn.commit()
						# Generate search results HTML
						search_results = [(ticker_input, price, timestamp)]
						search_results_html = generate_search_results_html(search_results)
						content = f'''
							<h2>Search Results</h2>
							{search_results_html}
							<p><a href="/">Back to Search</a></p>
						'''
					else:
						response = f"Could not retrieve data for ticker '{ticker_input}'. Please check the symbol and try again."
						content = f'''
							<h2>Search Results</h2>
							<p>{response}</p>
							<p><a href="/">Back to Search</a></p>
						'''
				else:
					response = "Invalid ticker format. Please enter 1-5 uppercase letters (e.g., AAPL)."
					content = f'''
						<h2>Search Results</h2>
						<p>{response}</p>
						<p><a href="/">Back to Search</a></p>
					'''
				# Replace the placeholder with actual content
				page = HTML_TEMPLATE.replace('{{ content }}', content)
				self.send_response(200)
				self.send_header("Content-type", "text/html; charset=utf-8")
				self.end_headers()
				self.wfile.write(page.encode("utf-8"))

			elif self.path == "/add_watch":
				# Handle adding a stock to the watchlist
				length = int(self.headers.get('Content-Length', 0))
				body = self.rfile.read(length).decode('utf-8')
				params = parse_qs(body)
				
				ticker_input = params.get("ticker", [""])[0].strip().upper()

				# Validate ticker: 1-5 uppercase letters
				if re.fullmatch(r'[A-Z]{1,5}', ticker_input):
					# Check if the ticker is already in the watchlist
					cursor.execute("SELECT 1 FROM watchlist WHERE ticker = ?", (ticker_input,))
					if cursor.fetchone():
						response = f"Ticker '{ticker_input}' is already in your watch list."
					else:
						# Add to watchlist
						timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
						cursor.execute("""
							INSERT INTO watchlist (ticker, timestamp)
							VALUES (?, ?)
						""", (ticker_input, timestamp))
						conn.commit()
						response = f"Ticker '{ticker_input}' has been added to your watch list."
				else:
					response = "Invalid ticker format. Please enter 1-5 uppercase letters (e.g., AAPL)."

				# Generate search results HTML with response
				search_results_html = generate_search_results_html([])
				content = f'''
					<h2>Add to Watch List</h2>
					<p>{response}</p>
					<p><a href="/">Back to Search</a></p>
				'''
				# Replace the placeholder with actual content
				page = HTML_TEMPLATE.replace('{{ content }}', content)
				self.send_response(200)
				self.send_header("Content-type", "text/html; charset=utf-8")
				self.end_headers()
				self.wfile.write(page.encode("utf-8"))

			elif self.path == "/remove_watch":
				# Handle removing a stock from the watchlist
				length = int(self.headers.get('Content-Length', 0))
				body = self.rfile.read(length).decode('utf-8')
				params = parse_qs(body)
				
				ticker_input = params.get("ticker", [""])[0].strip().upper()

				# Validate ticker
				if re.fullmatch(r'[A-Z]{1,5}', ticker_input):
					# Remove from watchlist
					cursor.execute("DELETE FROM watchlist WHERE ticker = ?", (ticker_input,))
					if cursor.rowcount > 0:
						response = f"Ticker '{ticker_input}' has been removed from your watch list."
					else:
						response = f"Ticker '{ticker_input}' was not found in your watch list."
				else:
					response = "Invalid ticker format. Please enter 1-5 uppercase letters (e.g., AAPL)."

				# Generate watchlist HTML with response
				watchlist_html = generate_watchlist_html()
				content = f'''
					<h2>Remove from Watch List</h2>
					<p>{response}</p>
					<p><a href="/watchlist">Back to Watch List</a></p>
				'''
				# Replace the placeholder with actual content
				page = HTML_TEMPLATE.replace('{{ content }}', content)
				self.send_response(200)
				self.send_header("Content-type", "text/html; charset=utf-8")
				self.end_headers()
				self.wfile.write(page.encode("utf-8"))

			else:
				# Handle other POST paths if necessary
				self.send_error(404, "Path not found.")
		except Exception as e:
			self.send_error(500, f"Internal Server Error: {e}")
			traceback.print_exc()

	def log_message(self, format, *args):
		# Override to prevent logging every request to stderr
		return

if __name__ == "__main__":
	try:
		server_address = ('0.0.0.0', 8004)  # Ensure this port is correct and available
		server = HTTPServer(server_address, Handler)
		print(f"Server started at http://{server_address[0]}:{server_address[1]}")
		server.serve_forever()
	except KeyboardInterrupt:
		print("\nServer shutting down.")
	except Exception as e:
		print(f"Error starting server: {e}")
		traceback.print_exc()
	finally:
		# Close the database connection when the server shuts down
		conn.close()