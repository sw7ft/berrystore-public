import http.server
import socketserver
import urllib.parse
import requests
import json

PORT = 8000

class OpenStreetMapHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        # Parse the URL and query parameters
        parsed_path = urllib.parse.urlparse(self.path)
        params = dict(urllib.parse.parse_qsl(parsed_path.query))

        # Check if the request is for the search endpoint
        if parsed_path.path == '/search':
            # Ensure the 'q' parameter is present
            if 'q' not in params:
                self.send_error(400, 'Missing search query')
                return

            query = params['q']
            try:
                # Define the Nominatim search parameters
                search_params = {
                    'format': 'json',
                    'q': query,
                    'limit': 5
                }
                url = 'https://nominatim.openstreetmap.org/search'

                # Set up the headers with a proper User-Agent as per Nominatim's policy
                headers = {
                    'User-Agent': 'PythonOSMApp/1.0 (your_email@example.com)'  # Replace with your contact info
                }

                # Make the GET request to Nominatim using requests
                response = requests.get(url, params=search_params, headers=headers)
                response.raise_for_status()  # Raise an exception for HTTP errors

                # Parse the JSON response
                results = response.json()

                # Send a successful JSON response back to the client
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(results).encode('utf-8'))

            except requests.RequestException as e:
                # Handle any errors that occur during the request
                self.send_error(500, f'Error fetching map data: {e}')

        else:
            # Serve the main HTML page for all other routes
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()

            # Define the HTML content with embedded JavaScript and Leaflet.js
            html_content = '''
            <!DOCTYPE html>
            <html>
            <head>
                <title>bb10 Maps</title>
                <!-- Leaflet.js CSS -->
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
                      integrity="sha256-oC6QbFtyOGbNp7G3l1DAuS61n/7N1kGqC2D92iO5iQY="
                      crossorigin=""/>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    body {
                        background-color: #1e1e1e;
                        color: white;
                        font-family: "Slate Pro", Slate, "Myriad Pro", Helvetica;
                        font-size: 12pt;
                        margin: 0;
                        padding: 0;
                        display: flex;
                        flex-direction: column;
                        min-height: 100vh;
                    }
                    .header {
                        background-color: #2b2b2b;
                        border-bottom: 2px solid #00769e !important;
                        padding: 10px;
                        text-align: center;
                        color: white;
                    }
                    h1 {
                        margin: 0;
                        font-size: 18pt;
                    }
                    /* Search Container */
                    .search-container {
                        width: 100%;
                        max-width: 500px;
                        display: flex;
                        flex-direction: column;
                        align-items: stretch;
                        margin: 20px auto;
                    }
                    .search-container input[type="text"] {
                        padding: 10px;
                        font-size: 14pt;
                        border: 1px solid #00769e;
                        border-radius: 4px;
                        margin-bottom: 10px;
                        background-color: #3a3a3a;
                        color: white;
                    }
                    .search-container button {
                        padding: 10px;
                        font-size: 14pt;
                        background-color: #00769e;
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        transition: background-color 0.2s;
                    }
                    .search-container button:hover {
                        background-color: #005f7a;
                    }
                    /* Map container styles */
                    #map {
                        width: 100%;
                        max-width: 800px;
                        height: 500px;
                        margin: 20px auto;
                        border: 1px solid #00769e;
                        border-radius: 4px;
                        background-color: #1e1e1e;
                    }
                    /* Responsive Design */
                    @media (max-width: 600px) {
                        .search-container {
                            margin: 10px;
                        }
                        #map {
                            height: 300px;
                            margin: 10px;
                        }
                        .search-container input[type="text"], .search-container button {
                            font-size: 12pt;
                            padding: 8px;
                        }
                        h1 {
                            font-size: 16pt;
                        }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>bb10 Maps</h1>
                </div>
                <div class="search-container">
                    <input type="text" id="searchInput" placeholder="Enter location">
                    <button onclick="searchLocation()">Search</button>
                </div>
                <div id="map"></div>

                <!-- Leaflet.js JavaScript -->
                <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
                        integrity="sha256-o9N1j6tA3GJt6fV6FvXqmC3vF+V5RIjCz5FLeJgqmc8="
                        crossorigin=""></script>
                <script type="text/javascript">
                    // Initialize the map variables
                    var mapInitialized = false;
                    var map;
                    var markersLayer = new L.LayerGroup();

                    // Function to initialize or update the map
                    function initializeMap(lat, lon) {
                        if (!mapInitialized) {
                            // Create the map and set its view
                            map = L.map('map').setView([lat, lon], 13);

                            // Add OpenStreetMap tiles to the map
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                maxZoom: 19,
                                attribution: '© OpenStreetMap'
                            }).addTo(map);

                            // Add the markers layer to the map
                            markersLayer.addTo(map);

                            mapInitialized = true;
                        } else {
                            map.setView([lat, lon], 13);
                        }
                    }

                    // ES5-compatible JavaScript function to search for a location
                    function searchLocation() {
                        var query = document.getElementById('searchInput').value;
                        if (!query) {
                            alert('Please enter a location to search.');
                            return;
                        }

                        var xhr = new XMLHttpRequest();
                        xhr.open('GET', '/search?q=' + encodeURIComponent(query), true);
                        
                        xhr.onload = function() {
                            if (xhr.status === 200) {
                                var results = JSON.parse(xhr.responseText);
                                var mapDiv = document.getElementById('map');

                                // Clear previous markers
                                markersLayer.clearLayers();

                                if (results.length === 0) {
                                    alert('No results found.');
                                    return;
                                }

                                // Iterate through the results and add markers
                                for (var i = 0; i < results.length; i++) {
                                    var r = results[i];
                                    
                                    // Add a marker for each result
                                    var marker = L.marker([r.lat, r.lon]);
                                    marker.bindPopup('<strong>' + r.display_name + '</strong>');
                                    markersLayer.addLayer(marker);
                                }

                                // Initialize or update the map to the first result's location
                                var firstResult = results[0];
                                initializeMap(firstResult.lat, firstResult.lon);
                            } else {
                                alert('Failed to load results.');
                            }
                        };
                        
                        xhr.onerror = function() {
                            alert('Error while fetching results.');
                        };
                        
                        xhr.send();
                    }
                </script>
            </body>
            </html>
            '''
            # Write the HTML content as bytes
            self.wfile.write(html_content.encode('utf-8'))

def run_server(port=8000):
    handler = OpenStreetMapHandler
    with socketserver.TCPServer(("", port), handler) as httpd:
        print(f"Serving at port {port}")
        print(f"Open your browser and navigate to http://localhost:{port}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down the server.")
            httpd.server_close()

if __name__ == "__main__":
    run_server()