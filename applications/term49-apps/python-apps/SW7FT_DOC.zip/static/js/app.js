/**
 * Office Word App - BB10 Compatible (ES5)
 */

// Global Variables
var currentDocument = {
    id: null,
    title: 'Untitled Document',
    content: '',
    lastModified: ''
};

// DOM Elements
var elements = {
    editor: null,
    title: null,
    wordCount: null,
    saveStatus: null,
    openDialog: null,
    saveDialog: null,
    documentsListContainer: null,
    saveDocumentTitle: null
};

// Document functions
function createNewDocument() {
    currentDocument = {
        id: null,
        title: 'Untitled Document',
        content: '',
        lastModified: new Date().toISOString()
    };
    
    updateUI();
}

function saveDocument() {
    // Show save dialog
    toggleSaveDialog(true);
}

function performSave() {
    // Update document data from UI
    currentDocument.title = elements.saveDocumentTitle.value || 'Untitled Document';
    elements.title.value = currentDocument.title; // Update the main title field too
    currentDocument.content = elements.editor.innerHTML;
    currentDocument.lastModified = new Date().toISOString();
    
    // Close dialog
    toggleSaveDialog(false);
    
    // Show saving status
    updateSaveStatus('Saving...');
    
    // Send to server
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/documents/save', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        currentDocument.id = response.id;
                        updateSaveStatus('Saved');
                        setTimeout(function() {
                            updateSaveStatus('Ready');
                        }, 2000);
                    } else {
                        updateSaveStatus('Error saving');
                    }
                } catch (e) {
                    updateSaveStatus('Error saving');
                }
            } else {
                updateSaveStatus('Error saving');
            }
        }
    };
    
    xhr.send(JSON.stringify(currentDocument));
}

function downloadDocument() {
    if (!currentDocument.id) {
        alert('Please save the document before downloading');
        saveDocument();
        return;
    }
    
    // Show format selection dialog
    var format = window.confirm('Download as HTML? (Cancel for plain text)') ? 'html' : 'text';
    
    updateSaveStatus('Preparing download...');
    
    var downloadUrl = '/api/documents/' + currentDocument.id + '/download?format=' + format;
    
    // Create temporary link and trigger download
    var link = document.createElement('a');
    link.href = downloadUrl;
    var extension = format === 'html' ? '.html' : '.txt';
    link.download = (currentDocument.title || 'Untitled') + extension;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setTimeout(function() {
        updateSaveStatus('Ready');
    }, 2000);
}

function loadDocument(docId) {
    if (!docId) return;
    
    updateSaveStatus('Loading...');
    
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/api/documents/' + docId, true);
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var doc = JSON.parse(xhr.responseText);
                    currentDocument = doc;
                    updateUI();
                    updateSaveStatus('Loaded');
                    setTimeout(function() {
                        updateSaveStatus('Ready');
                    }, 2000);
                } catch (e) {
                    updateSaveStatus('Error loading document');
                }
            } else {
                updateSaveStatus('Error loading document');
            }
        }
    };
    
    xhr.send();
}

function loadDocumentsList() {
    // Clear list and show loading
    elements.documentsListContainer.innerHTML = '<div class="loading-spinner">Loading...</div>';
    
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/api/documents', true);
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var documents = JSON.parse(xhr.responseText);
                    renderDocumentsList(documents);
                } catch (e) {
                    elements.documentsListContainer.innerHTML = '<div>Error loading documents</div>';
                }
            } else {
                elements.documentsListContainer.innerHTML = '<div>Error loading documents</div>';
            }
        }
    };
    
    xhr.send();
}

function renderDocumentsList(documents) {
    var html = '';
    
    if (documents.length === 0) {
        html = '<div>No documents found</div>';
    } else {
        for (var i = 0; i < documents.length; i++) {
            var doc = documents[i];
            var date = new Date(doc.lastModified);
            var formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
            
            html += '<div class="document-item" data-id="' + doc.id + '">' +
                    '<div class="document-title">' + doc.title + '</div>' +
                    '<div class="document-date">Last modified: ' + formattedDate + '</div>' +
                    '</div>';
        }
    }
    
    elements.documentsListContainer.innerHTML = html;
    
    // Add click handlers to document items
    var items = document.querySelectorAll('.document-item');
    for (var j = 0; j < items.length; j++) {
        items[j].addEventListener('click', function(e) {
            var docId = this.getAttribute('data-id');
            loadDocument(docId);
            toggleOpenDialog(false);
        });
    }
}

// UI Update functions
function updateUI() {
    elements.title.value = currentDocument.title || 'Untitled Document';
    elements.editor.innerHTML = currentDocument.content || '';
    updateWordCount();
}

function updateWordCount() {
    var text = elements.editor.innerText || '';
    var words = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
    elements.wordCount.innerText = 'Words: ' + words;
}

function updateSaveStatus(message) {
    elements.saveStatus.innerText = message;
}

// Format functions
function toggleBold() {
    document.execCommand('bold', false, null);
}

function toggleItalic() {
    document.execCommand('italic', false, null);
}

function toggleUnderline() {
    document.execCommand('underline', false, null);
}

function setFontFamily(family) {
    document.execCommand('fontName', false, family);
}

function setFontSize(size) {
    document.execCommand('fontSize', false, size);
}

function setAlignment(align) {
    document.execCommand('justify' + align, false, null);
}

function insertBulletList() {
    document.execCommand('insertUnorderedList', false, null);
}

function insertNumberList() {
    document.execCommand('insertOrderedList', false, null);
}

// Dialog functions
function toggleOpenDialog(show) {
    if (show) {
        elements.openDialog.className = 'dialog show';
        loadDocumentsList();
    } else {
        elements.openDialog.className = 'dialog';
    }
}

function toggleSaveDialog(show) {
    if (show) {
        elements.saveDialog.className = 'dialog show';
        elements.saveDocumentTitle.value = currentDocument.title || 'Untitled Document';
        // Put focus and select all text in the title field
        setTimeout(function() {
            elements.saveDocumentTitle.focus();
            elements.saveDocumentTitle.select();
        }, 100);
    } else {
        elements.saveDialog.className = 'dialog';
    }
}

// Event handlers
function setupEventListeners() {
    // Document operations
    document.getElementById('btn-new').addEventListener('click', function() {
        createNewDocument();
    });
    
    document.getElementById('btn-open').addEventListener('click', function() {
        toggleOpenDialog(true);
    });
    
    document.getElementById('btn-save').addEventListener('click', function() {
        saveDocument();
    });
    
    document.getElementById('btn-download').addEventListener('click', function() {
        downloadDocument();
    });
    
    // Open dialog close
    document.getElementById('close-open-dialog').addEventListener('click', function() {
        toggleOpenDialog(false);
    });
    
    document.getElementById('cancel-open').addEventListener('click', function() {
        toggleOpenDialog(false);
    });
    
    // Save dialog
    document.getElementById('close-save-dialog').addEventListener('click', function() {
        toggleSaveDialog(false);
    });
    
    document.getElementById('cancel-save').addEventListener('click', function() {
        toggleSaveDialog(false);
    });
    
    document.getElementById('confirm-save').addEventListener('click', function() {
        performSave();
    });
    
    // Allow pressing Enter in the save title field to save
    elements.saveDocumentTitle.addEventListener('keydown', function(e) {
        if (e.keyCode === 13) { // Enter key
            performSave();
        }
    });
    
    // Text formatting
    document.getElementById('format-bold').addEventListener('click', toggleBold);
    document.getElementById('format-italic').addEventListener('click', toggleItalic);
    document.getElementById('format-underline').addEventListener('click', toggleUnderline);
    
    document.getElementById('align-left').addEventListener('click', function() {
        setAlignment('Left');
    });
    
    document.getElementById('align-center').addEventListener('click', function() {
        setAlignment('Center');
    });
    
    document.getElementById('align-right').addEventListener('click', function() {
        setAlignment('Right');
    });
    
    document.getElementById('align-justify').addEventListener('click', function() {
        setAlignment('Full');
    });
    
    document.getElementById('format-list-bullet').addEventListener('click', insertBulletList);
    document.getElementById('format-list-number').addEventListener('click', insertNumberList);
    
    // Font family select
    document.getElementById('font-family').addEventListener('change', function() {
        setFontFamily(this.value);
    });
    
    // Font size select
    document.getElementById('font-size').addEventListener('change', function() {
        setFontSize(this.value);
    });
    
    // Editor content changes
    elements.editor.addEventListener('input', function() {
        updateWordCount();
        updateSaveStatus('Unsaved changes');
    });
    
    // Auto-save (every 30 seconds)
    setInterval(function() {
        if (elements.saveStatus.innerText === 'Unsaved changes' && currentDocument.id) {
            performSave();
        }
    }, 30000);
}

// Initialization
function initApp() {
    // Cache DOM elements
    elements.editor = document.getElementById('document-editor');
    elements.title = document.getElementById('document-title');
    elements.wordCount = document.getElementById('word-count');
    elements.saveStatus = document.getElementById('save-status');
    elements.openDialog = document.getElementById('open-dialog');
    elements.saveDialog = document.getElementById('save-dialog');
    elements.documentsListContainer = document.getElementById('documents-list');
    elements.saveDocumentTitle = document.getElementById('save-document-title');
    
    // Setup event listeners
    setupEventListeners();
    
    // Create a new document
    createNewDocument();
}

// Start the app when DOM is loaded
document.addEventListener('DOMContentLoaded', initApp); 