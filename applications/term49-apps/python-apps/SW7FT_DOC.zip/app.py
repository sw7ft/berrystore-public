import os
import json
import io
import traceback
import mimetypes
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse, parse_qsl

# Setup directories and paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
DOCUMENTS_DIR = os.path.join(BASE_DIR, "documents")

# Ensure required directories exist
for directory in [STATIC_DIR, DOCUMENTS_DIR]:
    if not os.path.exists(directory):
        os.makedirs(directory)

# Define content types
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("image/png", ".png")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("text/html", ".html")

# HTML to text conversion helper
def html_to_text(html):
    """Simple HTML to text conversion"""
    # Strip basic HTML tags
    text_content = html.replace('<p>', '\n\n').replace('</p>', '')
    text_content = text_content.replace('<br>', '\n').replace('<br/>', '\n')
    text_content = text_content.replace('<div>', '\n').replace('</div>', '')
    text_content = text_content.replace('<b>', '').replace('</b>', '')
    text_content = text_content.replace('<i>', '').replace('</i>', '')
    text_content = text_content.replace('<u>', '').replace('</u>', '')
    text_content = text_content.replace('&nbsp;', ' ')
    
    return text_content

# Create a simple HTML document for download
def create_html_document(html_content, title):
    """Create a standalone HTML document for download"""
    return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{title} - SW7FT DOC</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1 {{ color: #3a1c71; }}
    </style>
</head>
<body>
    <h1>{title}</h1>
    <div id="content">
        {html_content}
    </div>
    <div style="margin-top: 30px; font-size: 11px; color: #666;">
        Created with SW7FT DOC
    </div>
</body>
</html>
"""

class OfficeAppHandler(BaseHTTPRequestHandler):
    def send_static_file(self, file_path, content_type=None):
        """Helper to serve static files"""
        try:
            with open(file_path, 'rb') as file:
                content = file.read()
            
            self.send_response(200)
            if content_type:
                self.send_header('Content-Type', content_type)
            else:
                # Guess content type from file extension
                content_type, _ = mimetypes.guess_type(file_path)
                if content_type:
                    self.send_header('Content-Type', content_type)
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            print(f"Error serving {file_path}: {e}")
            self.send_error(404, f"File not found: {file_path}")

    def do_GET(self):
        try:
            parsed_path = urlparse(self.path)
            path = parsed_path.path
            query_params = dict(parse_qsl(parsed_path.query))
            
            # Root path serves the main app
            if path == "/" or path == "/index.html":
                html_path = os.path.join(BASE_DIR, "index.html")
                self.send_static_file(html_path, "text/html; charset=utf-8")
                return
                
            # Serve static files
            if path.startswith("/static/"):
                file_path = os.path.join(BASE_DIR, path[1:])  # Remove leading slash
                self.send_static_file(file_path)
                return
                
            # API to list documents
            if path == "/api/documents":
                try:
                    documents = []
                    for filename in os.listdir(DOCUMENTS_DIR):
                        if filename.endswith('.json'):
                            file_path = os.path.join(DOCUMENTS_DIR, filename)
                            with open(file_path, 'r') as f:
                                doc_data = json.load(f)
                                documents.append({
                                    "id": filename.replace('.json', ''),
                                    "title": doc_data.get("title", "Untitled"),
                                    "lastModified": doc_data.get("lastModified", "")
                                })
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps(documents).encode())
                except Exception as e:
                    print(f"Error listing documents: {e}")
                    self.send_error(500, f"Internal server error")
                return
                
            # API to get a document
            if path.startswith("/api/documents/") and path.count('/') == 3:
                doc_id = path.split("/")[-1]
                file_path = os.path.join(DOCUMENTS_DIR, f"{doc_id}.json")
                
                if os.path.exists(file_path):
                    with open(file_path, 'r') as f:
                        doc_data = json.load(f)
                    
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps(doc_data).encode())
                else:
                    self.send_error(404, f"Document not found: {doc_id}")
                return
            
            # API to download a document
            if path.startswith("/api/documents/") and path.endswith("/download"):
                doc_id = path.split("/")[-2]
                format_type = query_params.get('format', 'html')  # Default to HTML
                
                file_path = os.path.join(DOCUMENTS_DIR, f"{doc_id}.json")
                
                if os.path.exists(file_path):
                    with open(file_path, 'r') as f:
                        doc_data = json.load(f)
                    
                    title = doc_data.get("title", "Untitled")
                    content = doc_data.get("content", "")
                    
                    try:
                        if format_type == 'text':
                            # Text format
                            text_content = html_to_text(content)
                            output_content = (title + "\n\n" + text_content).encode('utf-8')
                            
                            self.send_response(200)
                            self.send_header('Content-Type', 'text/plain')
                            self.send_header('Content-Disposition', f'attachment; filename="{title}.txt"')
                            self.end_headers()
                            self.wfile.write(output_content)
                        else:
                            # HTML format
                            html_document = create_html_document(content, title)
                            
                            self.send_response(200)
                            self.send_header('Content-Type', 'text/html')
                            self.send_header('Content-Disposition', f'attachment; filename="{title}.html"')
                            self.end_headers()
                            self.wfile.write(html_document.encode('utf-8'))
                            
                    except Exception as e:
                        print(f"Error converting document: {e}")
                        traceback.print_exc()
                        self.send_error(500, f"Error converting document")
                else:
                    self.send_error(404, f"Document not found: {doc_id}")
                return
                
            # If path not recognized, return 404
            self.send_error(404, "Path not found")
            
        except Exception as e:
            print(f"Error handling GET request: {e}")
            traceback.print_exc()
            self.send_error(500, f"Internal Server Error: {e}")

    def do_POST(self):
        try:
            path = self.path
            
            # Save document
            if path == "/api/documents/save":
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length).decode('utf-8')
                document = json.loads(post_data)
                
                doc_id = document.get("id")
                if not doc_id:
                    # Generate a simple ID based on timestamp
                    import time
                    doc_id = f"doc_{int(time.time())}"
                    document["id"] = doc_id
                
                file_path = os.path.join(DOCUMENTS_DIR, f"{doc_id}.json")
                with open(file_path, 'w') as f:
                    json.dump(document, f)
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"success": True, "id": doc_id}).encode())
                return
                
            # If path not recognized, return 404
            self.send_error(404, "Path not found")
            
        except Exception as e:
            print(f"Error handling POST request: {e}")
            traceback.print_exc()
            self.send_error(500, f"Internal Server Error: {e}")

    def log_message(self, format, *args):
        # Override to prevent logging every request to stderr
        return

if __name__ == "__main__":
    try:
        server_address = ('0.0.0.0', 8015)  # Change port to 8015
        httpd = HTTPServer(server_address, OfficeAppHandler)
        print(f"Server started at http://{server_address[0]}:{server_address[1]}")
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer shutting down.")
    except Exception as e:
        print(f"Error starting server: {e}")
        traceback.print_exc() 