These ports are patched to support QNX.

liblzma: see require_c99.patch
libuuid: see qnx_support.patch
openssl: see restore_qnx_support.patch
python3: see 0011-qnx-configure.patch and config.site-qnx
